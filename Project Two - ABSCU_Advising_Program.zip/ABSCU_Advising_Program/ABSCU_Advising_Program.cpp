#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

struct Course {
    std::string courseNumber;
    std::string title;
    std::vector<std::string> prerequisites;
};

// Function to load course data from a file into a vector
void loadCourseData(std::vector<Course>& courses) {
    std::ifstream inputFile("ABCU_Advising_Program_Input.txt");
    if (!inputFile.is_open()) {
        std::cerr << "Error: Unable to open the file." << std::endl;
        return;
    }

    std::string line;
    while (std::getline(inputFile, line)) {
        std::istringstream iss(line);
        std::string courseInfo, prereqInfo;
        std::getline(iss, courseInfo, ',');
        Course course;
        course.courseNumber = courseInfo;

        if (std::getline(iss, course.title, ',')) {
            while (std::getline(iss, prereqInfo, ',')) {
                course.prerequisites.push_back(prereqInfo);
            }
        }

        courses.push_back(course);
    }

    inputFile.close();
}

// Function to print the list of courses
void printCourseList(const std::vector<Course>& courses) {
    std::cout << "Here is the list of courses:" << std::endl;
    for (const Course& course : courses) {
        std::cout << course.courseNumber << ", " << course.title << std::endl;
    }
}

// Function to print information about a specific course
void printCourseInformation(const std::vector<Course>& courses, const std::string& courseNumber) {
    bool found = false;
    for (const Course& course : courses) {
        if (course.courseNumber == courseNumber) {
            std::cout << course.courseNumber << ", " << course.title << std::endl;
            if (!course.prerequisites.empty()) {
                std::cout << "Prerequisites:";
                for (const std::string& prereq : course.prerequisites) {
                    std::cout << " " << prereq;
                }
                std::cout << std::endl;
            }
            else {
                std::cout << "No prerequisites" << std::endl;
            }
            found = true;
            break;
        }
    }

    if (!found) {
        std::cout << "Course not found: " << courseNumber << std::endl;
    }
}

int main() {
    std::vector<Course> courses;

    std::cout << "Welcome to the course planner." << std::endl;

    int choice = -1;
    while (choice != 9) {
        std::cout << "Menu:" << std::endl;
        std::cout << "1. Load Course Data" << std::endl;
        std::cout << "2. Print Course List" << std::endl;
        std::cout << "3. Print Course Information" << std::endl;
        std::cout << "9. Exit" << std::endl;
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            loadCourseData(courses);
            std::cout << "Course data loaded." << std::endl;
            break;
        case 2:
            printCourseList(courses);
            break;
        case 3: {
            std::string courseNumber;
            std::cout << "Enter the course number: ";
            std::cin >> courseNumber;
            printCourseInformation(courses, courseNumber);
            break;
        }
        case 9:
            std::cout << "Thank you for using the course planner!" << std::endl;
            break;
        default:
            std::cout << "Invalid choice. Please try again." << std::endl;
        }
    }

    return 0;
}
